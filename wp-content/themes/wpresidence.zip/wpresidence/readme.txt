Theme Name: Wp Residence
Theme URI: http://wpestatetheme.org/
Description:WP Residence is a premium & responsive WordPress theme designed for Real Estate companies and independent agents.
Version: 1.00
Author: Ana Maria - annapx0909@gmail.com
Author URI: 
Text Domain: wpestate
Tags: white, one-column, two-columns,left-sidebar, right-sidebar, fluid-layout , custom-menu, theme-options, translation-ready
License: 
License URI:

For help files go here http://help.wpresidence.net/